import { defineConfig, loadEnv, type RsbuildConfig } from "@rsbuild/core";
import { pluginEslint } from "@rsbuild/plugin-eslint";
import { pluginReact } from "@rsbuild/plugin-react";
import { pluginTypeCheck } from "@rsbuild/plugin-type-check";
import tailwindcssPostcssPlugin from "@tailwindcss/postcss";
import postcssImportPlugin from "postcss-import";
import postcssNestedPlugin from "postcss-nested";
import { readFileSync } from "fs";
import { resolve } from "path";

const { publicVars } = loadEnv({ prefixes: ["APP_"] });

const config: RsbuildConfig = defineConfig({
  dev: {
    cliShortcuts: {
      help: false,
    },
    lazyCompilation: {
      entries: true,
      imports: true,
    },
    progressBar: true,
  },
  html: {
    template: "./public/index.html",
  },
  plugins: [
    pluginEslint({
      enable: true,
      eslintPluginOptions: {
        configType: "flat",
        cwd: import.meta.dirname,
        exclude: ["dist", "node_modules"],
        failOnError: true,
      },
    }),
    pluginReact(),
    pluginTypeCheck(),
  ],
  resolve: {
    alias: {
      "react-flex-layout": "@eleung/react-grid-layout",
      "react-grid-layout": "@eleung/react-grid-layout",
      "@": resolve(import.meta.dirname, "src/app"),
      "~": resolve(import.meta.dirname, "src/dashboard"),
      "#": resolve(import.meta.dirname, "src/onboarding"),
    },
    extensions: [".js", ".ts", ".tsx"],
  },
  server: {
    host: "0.0.0.0",
    https: {
      cert: readFileSync(resolve(import.meta.dirname, "localhost-cert.pem")),
      key: readFileSync(resolve(import.meta.dirname, "localhost-key.pem")),
    },
  },
  source: {
    define: publicVars,
    exclude: [resolve(import.meta.dirname, "dist")],
    entry: {
      index: "./src/index.tsx",
    },
  },
  performance: {
    chunkSplit: {
      splitChunks: {
        cacheGroups: {
          primereact: {
            name: "primereact",
            priority: 10,
            test: /primereact/,
          },
          vendor: {
            name: "vendor",
            priority: 0,
            test: /node_modules/,
          },
        },
      },
      strategy: "custom",
    },
    removeConsole: ["log"],
  },
  tools: {
    rspack: (config, { rspack }) => {
      config.optimization ??= {};
      config.optimization.minimizer = [
        new rspack.SwcJsMinimizerRspackPlugin({ extractComments: false }),
      ];
      return config;
    },
    postcss: () => ({
      postcssOptions: {
        config: false,
        plugins: [
          postcssImportPlugin(),
          postcssNestedPlugin(),
          tailwindcssPostcssPlugin({
            optimize: false,
          }),
        ],
      },
    }),
  },
});

export default config;
