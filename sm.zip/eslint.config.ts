import eslintPluginBetterTailwindcss from "eslint-plugin-better-tailwindcss";
import eslintPluginStylistic from "@stylistic/eslint-plugin";
import eslintPluginImport from "eslint-plugin-import";
import eslintPluginReactNamingConvention from "eslint-plugin-react-naming-convention";
import eslintPluginPerfectionist from "eslint-plugin-perfectionist";
import eslintPluginReactDom from "eslint-plugin-react-dom";
import eslintPluginReactX from "eslint-plugin-react-x";
import { defineConfig } from "eslint/config";
import { configs, parser } from "typescript-eslint";

const config = defineConfig({
  extends: [configs.recommended],
  files: ["src/**/*.{ts,tsx}"],
  ignores: ["./dist/**/*"],
  languageOptions: {
    parser,
    parserOptions: {
      projectService: true,
      tsconfigRootDir: import.meta.dirname,
    },
  },
  plugins: {
    "@stylistic": eslintPluginStylistic,
    "better-tailwindcss": eslintPluginBetterTailwindcss,
    import: eslintPluginImport,
    perfectionist: eslintPluginPerfectionist,
    "react-dom": eslintPluginReactDom,
    "react-naming-convention": eslintPluginReactNamingConvention,
    "react-x": eslintPluginReactX,
  },
  rules: {
    "func-style": ["error", "expression"],
    "import/named": "off",
    "import/newline-after-import": "error",
    "import/order": "off",
    "no-multi-spaces": "error",
    "newline-after-var": "error",
    "newline-before-return": "error",
    "no-inline-comments": "error",
    "no-multiple-empty-lines": ["error", { max: 1 }],
    "no-restricted-syntax": [
      "error",
      "FunctionDeclaration",
      {
        message: "Avoid raw degree symbol in string literals. Use '\\u00B0'.",
        selector: "Literal[value=/°/u][raw!=/\\\\u00B0/u]",
      },
      {
        message: "Avoid raw degree symbol in template literals. Use '\\u00B0'.",
        selector: "TemplateElement[value.raw=/°/u]",
      },
    ],
    "no-trailing-spaces": "error",
    "no-unused-vars": "off",
    "prefer-const": "error",
    quotes: "error",
    semi: "error",
    "@stylistic/indent": [
      "error",
      2,
      {
        offsetTernaryExpressions: true,
        ignoredNodes: [
          "JSXExpressionContainer > ConditionalExpression",
          "JSXExpressionContainer > LogicalExpression",
          "TemplateLiteral *",
        ],
      },
    ],
    "@stylistic/jsx-closing-bracket-location": "error",
    "@stylistic/jsx-closing-tag-location": "error",
    "@stylistic/jsx-curly-brace-presence": "error",
    "@stylistic/jsx-curly-newline": "error",
    "@stylistic/jsx-curly-spacing": "error",
    "@stylistic/jsx-first-prop-new-line": "error",
    "@stylistic/jsx-indent-props": ["error", { indentMode: 2 }],
    "@stylistic/jsx-max-props-per-line": ["error", { maximum: 2 }],
    "@stylistic/jsx-tag-spacing": "error",
    "@stylistic/quotes": ["error", "double"],
    "@typescript-eslint/consistent-type-imports": "error",
    "@typescript-eslint/explicit-function-return-type": "error",
    "@typescript-eslint/no-explicit-any": "error",
    "@typescript-eslint/no-non-null-assertion": "off",
    "@typescript-eslint/no-unused-vars": [
      "error",
      { argsIgnorePattern: "_", varsIgnorePattern: "_" },
    ],
    // "better-tailwindcss/enforce-canonical-classes": "error",
    "better-tailwindcss/no-deprecated-classes": "error",
    "better-tailwindcss/no-conflicting-classes": "error",
    "better-tailwindcss/no-restricted-classes": [
      "error",
      {
        restrict: [
          {
            message: "HEX codes not allowed, use variable instead",
            pattern: "#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})",
          },
          // {
          //   message: "No px arbitrary values, use rem instead (px / 4)",
          //   pattern: "(?<!text-|rounded-|shadow-)\\[\\d+px\\]",
          // },
        ],
      },
    ],
    "better-tailwindcss/no-unnecessary-whitespace": "error",
    "perfectionist/sort-enums": "error",
    "perfectionist/sort-exports": "error",
    "perfectionist/sort-imports": [
      "error",
      {
        customGroups: [
          {
            groupName: "type-react",
            elementNamePattern: ["^react$", "^react-.*"],
            selector: "type",
          },
          {
            groupName: "react",
            elementNamePattern: ["^react$", "^react-.*"],
          },
          {
            groupName: "internal-alias",
            elementNamePattern: ["^@/.+"],
          },
          {
            groupName: "internal-tilde",
            elementNamePattern: ["^~/.+"],
          },
          {
            groupName: "internal-hash",
            elementNamePattern: ["^#/.+"],
          },
        ],
        groups: [
          "side-effect",
          { newlinesBetween: 1 },
          "builtin",
          { newlinesBetween: 1 },
          "react",
          { newlinesBetween: 0 },
          "external",
          { newlinesBetween: 1 },
          "internal-alias",
          { newlinesBetween: 1 },
          "internal-tilde",
          { newlinesBetween: 1 },
          "internal-hash",
          { newlinesBetween: 1 },

          "parent",
          { newlinesBetween: 1 },
          "sibling",
          { newlinesBetween: 1 },
          "index",
          { newlinesBetween: 1 },
          "import",
          { newlinesBetween: 1 },

          "type-react",
          { newlinesBetween: 0 },
          "type-external",
          { newlinesBetween: 0 },
          "type-internal",
          { newlinesBetween: 0 },
          "type-parent",
          { newlinesBetween: 0 },
          "type-sibling",
          { newlinesBetween: 0 },
          "type-index",
          { newlinesBetween: 1 },
          "type-import",
          { newlinesBetween: 1 },
        ],
        internalPattern: ["^@/.+", "^~/.+", "^#/.+"],
        newlinesBetween: 1,
        order: "asc",
        type: "natural",
      },
    ],
    "perfectionist/sort-interfaces": "error",
    "perfectionist/sort-jsx-props": "error",
    "perfectionist/sort-named-exports": "error",
    "perfectionist/sort-object-types": "error",
    "perfectionist/sort-objects": "error",
    "perfectionist/sort-union-types": "error",
    "react-dom/no-missing-button-type": "error",
    "react-dom/no-string-style-prop": "error",
    "react-naming-convention/context-name": "error",
    "react-naming-convention/id-name": "error",
    "react-naming-convention/ref-name": "error",
    "react-x/jsx-key-before-spread": "error",
    "react-x/jsx-shorthand-boolean": "error",
    "react-x/jsx-shorthand-fragment": "error",
    "react-x/no-array-index-key": "error",
    "react-x/no-class-component": "error",
    "react-x/no-context-provider": "error",
    "react-x/no-duplicate-key": "error",
    "react-x/no-missing-key": "error",
  },
  settings: {
    "better-tailwindcss": {
      entryPoint: "./src/css/init.css",
    },
  },
});

export default config;
